/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cinema.cine.logic;

/**
 *
 * @author Lenovo
 */
public class Ticket {

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public void setPelicula(Pelicula pelicula) {
        this.pelicula = pelicula;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Ticket(String codigo, String cantidad, Pelicula pelicula, Cliente cliente) {
        this.codigo = codigo;
        this.cantidad = cantidad;
        this.pelicula = pelicula;
        this.cliente = cliente;
    }

    public Ticket() {
    }
   
    
    private String codigo;
    private String cantidad;
    private Pelicula pelicula;
    private Cliente cliente;
}
