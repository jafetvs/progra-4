/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cinema.cine.presentation.inicio;

import com.cinema.cine.logic.Pelicula;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Model {
    List<Pelicula> peliculas;
    
    public Model(){
        peliculas = new ArrayList<>();
    }
    

    public List<Pelicula> getPeliculas() {
        return peliculas;
    }

    public void setPeliculas(List<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }
}
