/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cinema.cine.presentation.detalle;

import com.cinema.cine.logic.Cliente;
import com.cinema.cine.logic.Pelicula;
import com.cinema.cine.logic.Ticket;

/**
 *
 * @author Lenovo
 */
public class Model {
    
    

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    Ticket ticket;
    
    Cliente cliente;
    
    Pelicula pelicula;
    
    public Model(){}

    public Model(Pelicula pelicula, Ticket ticket, Cliente cliente) {
        this.pelicula = pelicula;
        this.ticket = ticket;
        this.cliente = cliente;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public void setPelicula(Pelicula pelicula) {
        this.pelicula = pelicula;
    }
    
}
