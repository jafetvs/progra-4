/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cinema.cine.logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Escinf
 */
public class Service {
    private static Service uniqueInstance;
    
    public static Service instance(){
        if (uniqueInstance == null){
            uniqueInstance = new Service();
        }
        return uniqueInstance; 
    }

    HashMap<String,Pelicula> peliculas;
    HashMap<String,List<String>> favoritas;
    List<Ticket> tickets;
    List<Cliente> clientes;
    
    
    private Service(){
        peliculas = new HashMap();
        peliculas.put("001", new Pelicula("001","La Casa de Papel", "2D", "Doblada", "1.5", "Documental"));
        peliculas.put("002", new Pelicula("002","Spider-Man: No Way Home", "3D", "Subtitulada", "2.3", "Accion"));
        peliculas.put("003", new Pelicula("003","Avenger", "2D", "Doblada", "1.5", "Accion"));
        
        tickets = new ArrayList<>();
        clientes = new ArrayList<>();
    }
    
   
    public List<Pelicula> obtenerPeliculas() {
    List<Pelicula> peliculasList = new ArrayList<>();
    for (Map.Entry<String, Pelicula> entry : peliculas.entrySet()) {
        peliculasList.add(entry.getValue());
    }
    return peliculasList;
    }
    
    public Pelicula getPeliculaByCodigo(String peliculaCodigo) {
    for (Map.Entry<String, Pelicula> entry : peliculas.entrySet()) {
        if (entry.getKey().equals(peliculaCodigo)) {
            return entry.getValue();
        }
    }
    return null; // o lanza una excepción si no se encuentra la película
    }

//    00

//    public Cliente clienteFind(Usuario usuario) throws Exception{
//        if (clientes.get(usuario.getCedula())!=null) return clientes.get(usuario.getCedula());
//        else throw new Exception("Cliente no existe");
//    }    
//    public List<Cuenta> cuentasFind(Cliente cliente) throws Exception{
//        List<Cuenta> result = new ArrayList();
//        for(Cuenta c: cuentas.values()){
//            if(c.getCliente().equals(cliente)){
//                result.add(c);
//            }
//        }
//        return result;
//    }
//    
//    public List<Cuenta> favoritasFind(Cliente cliente) throws Exception{
//        List<Cuenta> result = new ArrayList();
//        for(String nc: favoritas.get(cliente.getCedula())){
//                result.add(cuentas.get(nc));
//        }
//        return result;
//    }
//
//    public void clienteUpdate(Cliente cliente) throws Exception{
//        if (clientes.get(cliente.getCedula())==null) 
//            throw new Exception("Cliente no existe");
//        else{
//            clientes.get(cliente.getCedula()).setNombre(cliente.getNombre());
//        }
//    }
//    
    public Ticket ticketFind(String codigo) throws Exception{
        for (Ticket ticket : tickets) {
        if (ticket.getCodigo().equals(codigo)) {
            return ticket;
        }
    }
    return null;
    }    

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
}
