/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jafetvs.login.presentacion.login;

import jafetvs.login.login.Usuario;






/**
 *
 * @author ESCINF
 */
public class Model {
    Usuario usuario;

    public Model(Usuario usuario) {
        this.usuario = usuario;
    }

    public Model() {
    }
    
}
